Canvasloth.Math = function() {};
